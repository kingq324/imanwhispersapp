import React, { useState, useEffect, useRef } from 'react';
import { 
  Moon, Sun, Compass, BookOpen, Scroll, Heart, Volume2, VolumeX, Play, Pause, 
  RotateCcw, Bookmark, Share2, Search, CheckCircle2, ChevronRight, Clock, 
  MapPin, Bell, Sparkles, Filter, Grid, List, Shield, RefreshCw
} from 'lucide-react';

// Main App Component
export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Custom Brand Logo Component
  const Logo = ({ className = "w-12 h-12" }) => (
    <div className={`relative flex items-center justify-center rounded-full bg-gradient-to-br from-pink-500 via-rose-600 to-pink-700 p-[3px] shadow-md shadow-pink-200 dark:shadow-pink-900/30 ${className}`}>
      <div className="w-full h-full bg-rose-50 dark:bg-zinc-900 rounded-full flex flex-col items-center justify-center border-2 border-pink-200 dark:border-pink-800 p-1 text-center relative overflow-hidden">
        {/* Crescent Moon & Lantern Accent */}
        <div className="absolute top-1 right-2 opacity-20 text-rose-600">
          🌙
        </div>
        <span className="font-serif italic font-extrabold text-xs leading-none text-rose-600 dark:text-pink-400 tracking-tight">Iman</span>
        <span className="font-serif italic text-[10px] leading-none text-pink-700 dark:text-pink-300">Whispers</span>
        <div className="w-6 h-[1px] bg-rose-400 my-[1px] opacity-60"></div>
        <span className="text-[5px] font-sans font-bold tracking-widest text-rose-800 dark:text-pink-200 uppercase">Faith • Peace</span>
      </div>
    </div>
  );

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-zinc-950 text-pink-50' : 'bg-gradient-to-br from-rose-50/70 via-pink-50/40 to-slate-50 text-slate-800'} transition-colors duration-300 flex justify-center`}>
      {/* Container - Styled as high-end mobile/tablet dashboard view */}
      <div className="w-full max-w-md md:max-w-2xl lg:max-w-4xl min-h-screen flex flex-col shadow-2xl bg-white/80 dark:bg-zinc-900/90 backdrop-blur-md relative border-x border-pink-100 dark:border-zinc-800">
        
        {/* Top Header Navbar */}
        <header className="sticky top-0 z-40 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-lg border-b border-pink-100 dark:border-zinc-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo className="w-12 h-12" />
            <div>
              <h1 className="font-serif text-lg font-bold bg-gradient-to-r from-rose-600 to-pink-600 dark:from-pink-400 dark:to-rose-400 bg-clip-text text-transparent flex items-center gap-1.5">
                Iman Whispers
                <Sparkles className="w-4 h-4 text-pink-500 fill-pink-300 dark:fill-pink-700" />
              </h1>
              <p className="text-[10px] font-semibold tracking-widest text-pink-700/80 dark:text-pink-300/80 uppercase">
                FAITH • REMINDERS • PEACE
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 rounded-full bg-rose-50 dark:bg-zinc-800 text-rose-600 dark:text-pink-300 hover:bg-rose-100 transition-colors"
              aria-label="Toggle Theme"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* Dynamic Content Area */}
        <main className="flex-1 pb-24 px-4 pt-4 overflow-y-auto">
          {activeTab === 'home' && <HomeScreen setActiveTab={setActiveTab} />}
          {activeTab === 'quran' && <QuranScreen />}
          {activeTab === 'hadith' && <HadithScreen />}
          {activeTab === 'tasbeeh' && <TasbeehScreen />}
          {activeTab === 'duas' && <DuasScreen />}
        </main>

        {/* Bottom Navigation Bar */}
        <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md md:max-w-2xl lg:max-w-4xl bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md border-t border-pink-100 dark:border-zinc-800 px-3 py-2 z-50 flex justify-around items-center">
          {[
            { id: 'home', label: 'Home', icon: Sparkles },
            { id: 'quran', label: 'Quran', icon: BookOpen },
            { id: 'hadith', label: 'Hadith', icon: Scroll },
            { id: 'tasbeeh', label: 'Tasbeeh', icon: RotateCcw },
            { id: 'duas', label: 'Duas', icon: Heart },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center py-1 px-3 rounded-2xl transition-all duration-200 ${
                  isActive 
                    ? 'text-rose-600 dark:text-pink-400 font-semibold scale-105 bg-rose-50 dark:bg-rose-950/40' 
                    : 'text-zinc-500 dark:text-zinc-400 hover:text-rose-500'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                <span className="text-[11px] mt-1">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}

// ==================== 1. HOME DASHBOARD ====================
function HomeScreen({ setActiveTab }) {
  const [nextPrayerTimer, setNextPrayerTimer] = useState({ name: 'Asr', hours: '01', mins: '42', secs: '15' });
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      const date = new Date();
      const secs = (59 - date.getSeconds()).toString().padStart(2, '0');
      const mins = (41 - (date.getMinutes() % 40)).toString().padStart(2, '0');
      setNextPrayerTimer(prev => ({ ...prev, mins, secs }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const prayers = [
    { name: 'Fajr', time: '05:12 AM', active: false },
    { name: 'Dhuhr', time: '12:15 PM', active: false },
    { name: 'Asr', time: '03:45 PM', active: true },
    { name: 'Maghrib', time: '06:18 PM', active: false },
    { name: 'Isha', time: '07:35 PM', active: false },
  ];

  return (
    <div className="space-y-5">
      {/* Banner / Prayer Countdown Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-600 via-pink-600 to-rose-700 text-white p-5 shadow-xl shadow-rose-200 dark:shadow-rose-950/40">
        <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none"></div>
        <div className="flex justify-between items-start mb-3 relative z-10">
          <div>
            <div className="flex items-center gap-1.5 text-rose-100 text-xs font-medium">
              <MapPin className="w-3.5 h-3.5" />
              <span>Lahore, Pakistan • Today</span>
            </div>
            <h2 className="text-2xl font-bold mt-1">Next: {nextPrayerTimer.name}</h2>
          </div>
          <span className="bg-white/20 backdrop-blur-md text-white text-xs px-3 py-1 rounded-full font-semibold flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 animate-spin-slow" /> Qibla 262°
          </span>
        </div>

        {/* Countdown Timer */}
        <div className="flex items-center gap-2 my-4 justify-start">
          <div className="bg-white/15 backdrop-blur-md px-3 py-2 rounded-xl text-center min-w-[55px]">
            <span className="text-2xl font-bold font-mono">{nextPrayerTimer.hours}</span>
            <span className="block text-[9px] uppercase tracking-wider text-rose-100">Hours</span>
          </div>
          <span className="text-xl font-bold">:</span>
          <div className="bg-white/15 backdrop-blur-md px-3 py-2 rounded-xl text-center min-w-[55px]">
            <span className="text-2xl font-bold font-mono">{nextPrayerTimer.mins}</span>
            <span className="block text-[9px] uppercase tracking-wider text-rose-100">Mins</span>
          </div>
          <span className="text-xl font-bold">:</span>
          <div className="bg-white/15 backdrop-blur-md px-3 py-2 rounded-xl text-center min-w-[55px]">
            <span className="text-2xl font-bold font-mono">{nextPrayerTimer.secs}</span>
            <span className="block text-[9px] uppercase tracking-wider text-rose-100">Secs</span>
          </div>
        </div>

        {/* Mini Prayer Times Strip */}
        <div className="grid grid-cols-5 gap-1.5 pt-2 border-t border-white/20 text-center">
          {prayers.map((p) => (
            <div key={p.name} className={`py-1.5 rounded-lg ${p.active ? 'bg-white text-rose-600 font-bold shadow-md' : 'text-rose-100'}`}>
              <div className="text-[10px] uppercase font-semibold">{p.name}</div>
              <div className="text-[11px] font-medium">{p.time}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Verse of the Day Card */}
      <div className="bg-white dark:bg-zinc-800/80 rounded-3xl p-5 border border-pink-100 dark:border-zinc-700 shadow-sm relative overflow-hidden">
        <div className="flex justify-between items-center mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-pink-400 bg-rose-50 dark:bg-rose-950/50 px-3 py-1 rounded-full flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> Ayah of the Day
          </span>
          <span className="text-xs text-zinc-400 font-medium">Surah Ar-Rahman [55:13]</span>
        </div>

        {/* Arabic Text */}
        <p className="text-right font-serif text-2xl leading-loose text-zinc-800 dark:text-zinc-100 my-3 font-semibold">
          فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ
        </p>
        <p className="text-xs italic text-zinc-500 dark:text-zinc-400 mb-2">
          Fabi-ayyi ala-i rabbikuma tukazziban
        </p>
        <p className="text-sm text-zinc-700 dark:text-zinc-300 font-medium leading-relaxed">
          "So which of the favors of your Lord would you deny?"
        </p>

        {/* Verse Action Bar */}
        <div className="flex justify-between items-center mt-4 pt-3 border-t border-pink-50 dark:border-zinc-700">
          <button 
            onClick={() => setIsPlayingAudio(!isPlayingAudio)} 
            className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-pink-400 font-semibold bg-rose-50 dark:bg-rose-950/40 px-3 py-1.5 rounded-full hover:bg-rose-100 transition"
          >
            {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            {isPlayingAudio ? 'Pause Recitation' : 'Listen Ayah'}
          </button>
          
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-full hover:bg-rose-50 dark:hover:bg-zinc-700 text-zinc-500 dark:text-zinc-300">
              <Bookmark className="w-4 h-4" />
            </button>
            <button className="p-2 rounded-full hover:bg-rose-50 dark:hover:bg-zinc-700 text-zinc-500 dark:text-zinc-300">
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Daily Reminders / Hadith Card */}
      <div className="bg-gradient-to-r from-pink-50 to-rose-50 dark:from-zinc-800 dark:to-zinc-800/90 rounded-3xl p-4 border border-pink-200/60 dark:border-zinc-700 flex items-start gap-3">
        <div className="p-3 bg-rose-600 text-white rounded-2xl shrink-0 mt-1 shadow-md shadow-pink-200 dark:shadow-none">
          <Scroll className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <div className="text-xs font-bold text-rose-600 dark:text-pink-400 uppercase tracking-wide">
            Daily Whisper of Faith
          </div>
          <p className="text-xs text-zinc-700 dark:text-zinc-300 mt-1 leading-relaxed italic">
            "The most beloved of deeds to Allah are those that are most consistent, even if they are small." — Sahih Bukhari
          </p>
        </div>
      </div>

      {/* Quick Access Feature Grid */}
      <div>
        <h3 className="text-sm font-bold text-zinc-700 dark:text-zinc-200 mb-3 px-1">
          Explore Features
        </h3>
        <div className="grid grid-cols-3 gap-3">
          {[
            { id: 'quran', name: 'Holy Quran', icon: BookOpen, desc: 'Read & Listen', color: 'from-pink-500 to-rose-600' },
            { id: 'hadith', name: 'Hadith Books', icon: Scroll, desc: '6 Collections', color: 'from-rose-500 to-pink-600' },
            { id: 'tasbeeh', name: 'Tasbeeh', icon: RotateCcw, desc: 'Dhikr Counter', color: 'from-pink-600 to-rose-700' },
            { id: 'duas', name: 'Duas & Azkar', icon: Heart, desc: 'Daily Prayers', color: 'from-rose-600 to-pink-500' },
            { id: 'qibla', name: 'Qibla Compass', icon: Compass, desc: 'Find Direction', color: 'from-pink-500 to-rose-500', action: () => alert('Qibla Direction: 262° West-Southwest from your location.') },
            { id: 'prayer', name: 'Schedule', icon: Clock, desc: 'Full Timings', color: 'from-rose-500 to-pink-600', action: () => alert('Prayer Timings loaded for your current region.') }
          ].map((item) => (
            <button
              key={item.id}
              onClick={item.action || (() => setActiveTab(item.id))}
              className="bg-white dark:bg-zinc-800 p-3.5 rounded-2xl border border-pink-100 dark:border-zinc-700/80 shadow-sm hover:shadow-md transition-all text-left flex flex-col justify-between group"
            >
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${item.color} text-white flex items-center justify-center shadow-md mb-2 group-hover:scale-110 transition-transform`}>
                <item.icon className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-zinc-800 dark:text-zinc-100">{item.name}</div>
                <div className="text-[10px] text-zinc-400 dark:text-zinc-400 mt-0.5">{item.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ==================== 2. HOLY QURAN SCREEN ====================
function QuranScreen() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSurah, setSelectedSurah] = useState(null);
  const [activeReciter, setActiveReciter] = useState('Mishary Rashid Alafasy');

  const surahs = [
    { number: 1, name: 'Al-Fatiha', arabic: 'الفاتحة', verses: 7, type: 'Meccan', meaning: 'The Opening' },
    { number: 2, name: 'Al-Baqarah', arabic: 'البقرة', verses: 286, type: 'Medinan', meaning: 'The Cow' },
    { number: 36, name: 'Yaseen', arabic: 'يس', verses: 83, type: 'Meccan', meaning: 'Ya-Sin' },
    { number: 55, name: 'Ar-Rahman', arabic: 'الرحمن', verses: 78, type: 'Medinan', meaning: 'The Beneficent' },
    { number: 67, name: 'Al-Mulk', arabic: 'الملك', verses: 30, type: 'Meccan', meaning: 'The Sovereignty' },
    { number: 18, name: 'Al-Kahf', arabic: 'الكهف', verses: 110, type: 'Meccan', meaning: 'The Cave' },
    { number: 112, name: 'Al-Ikhlas', arabic: 'الإخلاص', verses: 4, type: 'Meccan', meaning: 'Purity' },
    { number: 113, name: 'Al-Falaq', arabic: 'الفلق', verses: 5, type: 'Meccan', meaning: 'The Daybreak' },
    { number: 114, name: 'An-Nas', arabic: 'الناس', verses: 6, type: 'Meccan', meaning: 'Mankind' },
  ];

  const sampleAyahs = [
    { num: 1, arabic: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', trans: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.', urdu: 'اللہ کے نام سے جو بے حد مہربان، نہایت رحم کرنے والا ہے۔' },
    { num: 2, arabic: 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ', trans: '[All] praise is due to Allah, Lord of the worlds -', urdu: 'سب تعریفیں اللہ ہی کے لیے ہیں جو تمام جہانوں کا پرورش کرنے والا ہے۔' },
    { num: 3, arabic: 'ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', trans: 'The Entirely Merciful, the Especially Merciful,', urdu: 'بہت مہربان، نہایت رحم کرنے والا۔' },
    { num: 4, arabic: 'مَٰلِكِ يَوْمِ ٱلدِّينِ', trans: 'Sovereign of the Day of Recompense.', urdu: 'روز جزا کا مالک۔' },
  ];

  const filteredSurahs = surahs.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.meaning.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Search Header */}
      {!selectedSurah ? (
        <>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-zinc-400" />
            <input 
              type="text" 
              placeholder="Search Surah by name or meaning..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-zinc-800 rounded-2xl border border-pink-100 dark:border-zinc-700 text-xs text-zinc-800 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>

          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-zinc-600 dark:text-zinc-300">Surah Directory</span>
            <span className="text-[11px] text-pink-600 dark:text-pink-400 font-semibold">114 Surahs</span>
          </div>

          {/* Surah List */}
          <div className="space-y-2.5">
            {filteredSurahs.map((surah) => (
              <div 
                key={surah.number}
                onClick={() => setSelectedSurah(surah)}
                className="bg-white dark:bg-zinc-800/80 p-3.5 rounded-2xl border border-pink-100 dark:border-zinc-700/80 flex items-center justify-between hover:border-pink-300 transition cursor-pointer shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-pink-400 font-bold flex items-center justify-center text-xs border border-rose-100 dark:border-rose-900">
                    {surah.number}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-zinc-800 dark:text-zinc-100">{surah.name}</div>
                    <div className="text-[11px] text-zinc-400">{surah.meaning} • {surah.verses} Verses</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-serif text-lg font-bold text-rose-600 dark:text-pink-400">{surah.arabic}</div>
                  <div className="text-[10px] text-zinc-400">{surah.type}</div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        /* Surah Reader View */
        <div className="space-y-4">
          <button 
            onClick={() => setSelectedSurah(null)}
            className="text-xs font-semibold text-rose-600 dark:text-pink-400 flex items-center gap-1 hover:underline mb-2"
          >
            ← Back to Surah Index
          </button>

          <div className="bg-gradient-to-r from-rose-600 to-pink-600 text-white rounded-3xl p-5 text-center shadow-lg">
            <h2 className="text-2xl font-bold font-serif">{selectedSurah.name}</h2>
            <p className="text-xs opacity-90">{selectedSurah.meaning} • {selectedSurah.type} • {selectedSurah.verses} Verses</p>
            <div className="mt-3 inline-block bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-serif">
              بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
            </div>
          </div>

          {/* Ayahs List */}
          <div className="space-y-4">
            {sampleAyahs.map((ayah) => (
              <div key={ayah.num} className="bg-white dark:bg-zinc-800 p-4 rounded-2xl border border-pink-100 dark:border-zinc-700 shadow-sm space-y-3">
                <div className="flex justify-between items-center text-xs text-zinc-400">
                  <span className="w-6 h-6 rounded-full bg-rose-50 dark:bg-zinc-700 text-rose-600 dark:text-pink-400 font-bold flex items-center justify-center text-[10px]">
                    {ayah.num}
                  </span>
                  <div className="flex items-center gap-2">
                    <button className="hover:text-rose-600"><Bookmark className="w-3.5 h-3.5" /></button>
                    <button className="hover:text-rose-600"><Play className="w-3.5 h-3.5" /></button>
                    <button className="hover:text-rose-600"><Share2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
                <p className="text-right font-serif text-2xl leading-loose text-zinc-800 dark:text-zinc-100 font-semibold">
                  {ayah.arabic}
                </p>
                <p className="text-xs text-zinc-600 dark:text-zinc-300 font-medium">
                  {ayah.trans}
                </p>
                <p className="text-xs text-rose-700/80 dark:text-pink-300/80 font-serif text-right">
                  {ayah.urdu}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== 3. HADITH SCREEN ====================
function HadithScreen() {
  const [activeBook, setActiveBook] = useState('Bukhari');
  const [hadithSearch, setHadithSearch] = useState('');

  const books = [
    { id: 'Bukhari', name: 'Sahih Bukhari', count: '7,563 Hadiths' },
    { id: 'Muslim', name: 'Sahih Muslim', count: '7,500 Hadiths' },
    { id: 'Dawud', name: 'Sunan Abi Dawud', count: '5,274 Hadiths' },
    { id: 'Nasai', name: 'Sunan An-Nasa\'i', count: '5,758 Hadiths' },
  ];

  const sampleHadiths = [
    {
      id: 1,
      book: 'Sahih Bukhari',
      number: 'Hadith #1',
      topic: 'Intentions',
      arabic: 'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى',
      english: 'Actions are judged by intentions, and every person will get what they intended.',
      narrator: 'Narrated by Umar bin Al-Khattab (RA)',
      tag: 'Sahih (Authentic)'
    },
    {
      id: 2,
      book: 'Sahih Bukhari',
      number: 'Hadith #13',
      topic: 'Brotherhood',
      arabic: 'لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ',
      english: 'None of you truly believes until he loves for his brother what he loves for himself.',
      narrator: 'Narrated by Anas (RA)',
      tag: 'Sahih (Authentic)'
    }
  ];

  return (
    <div className="space-y-4">
      {/* Book Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {books.map((b) => (
          <button
            key={b.id}
            onClick={() => setActiveBook(b.id)}
            className={`px-3.5 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition ${
              activeBook === b.id 
                ? 'bg-rose-600 text-white shadow-md shadow-pink-200 dark:shadow-none' 
                : 'bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border border-pink-100 dark:border-zinc-700'
            }`}
          >
            {b.name}
          </button>
        ))}
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-zinc-400" />
        <input 
          type="text" 
          placeholder="Search Hadith by keyword, topic, or narrator..."
          value={hadithSearch}
          onChange={(e) => setHadithSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-zinc-800 rounded-2xl border border-pink-100 dark:border-zinc-700 text-xs text-zinc-800 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-rose-500"
        />
      </div>

      {/* Hadith List */}
      <div className="space-y-3">
        {sampleHadiths.map((h) => (
          <div key={h.id} className="bg-white dark:bg-zinc-800 p-4 rounded-3xl border border-pink-100 dark:border-zinc-700 shadow-sm space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-1 rounded-full">
                {h.tag}
              </span>
              <span className="text-xs text-zinc-400">{h.book} • {h.number}</span>
            </div>

            <p className="text-right font-serif text-xl leading-relaxed text-zinc-800 dark:text-zinc-100 font-semibold pt-1">
              {h.arabic}
            </p>
            <p className="text-xs text-zinc-700 dark:text-zinc-300 font-medium leading-relaxed">
              "{h.english}"
            </p>
            <div className="text-[11px] text-zinc-400 italic">
              {h.narrator}
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-pink-50 dark:border-zinc-700/60">
              <span className="text-[11px] font-semibold text-rose-600 dark:text-pink-400">Topic: {h.topic}</span>
              <div className="flex items-center gap-2">
                <button className="p-1.5 rounded-full hover:bg-rose-50 text-zinc-500"><Bookmark className="w-4 h-4" /></button>
                <button className="p-1.5 rounded-full hover:bg-rose-50 text-zinc-500"><Share2 className="w-4 h-4" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== 4. TASBEEH COUNTER SCREEN ====================
function TasbeehScreen() {
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(33);
  const [selectedPhrase, setSelectedPhrase] = useState('SubhanAllah');
  const [lap, setLap] = useState(0);

  const phrases = [
    { name: 'SubhanAllah', arabic: 'سُبْحَانَ اللَّهِ', target: 33 },
    { name: 'Alhamdulillah', arabic: 'الْحَمْدُ لِلَّهِ', target: 33 },
    { name: 'Allahu Akbar', arabic: 'اللَّهُ أَكْبَرُ', target: 34 },
    { name: 'Astaghfirullah', arabic: 'أَسْتَغْفِرُ اللَّهَ', target: 100 },
  ];

  const handleIncrement = () => {
    if (count + 1 >= target) {
      setCount(0);
      setLap(prev => prev + 1);
    } else {
      setCount(prev => prev + 1);
    }
  };

  const handleReset = () => {
    setCount(0);
    setLap(0);
  };

  return (
    <div className="space-y-5 text-center">
      {/* Phrase Selector Slider */}
      <div className="grid grid-cols-2 gap-2">
        {phrases.map((p) => (
          <button
            key={p.name}
            onClick={() => {
              setSelectedPhrase(p.name);
              setTarget(p.target);
              setCount(0);
            }}
            className={`p-3 rounded-2xl border text-left transition ${
              selectedPhrase === p.name
                ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white border-transparent shadow-md'
                : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 border-pink-100 dark:border-zinc-700'
            }`}
          >
            <div className="text-xs font-bold">{p.name}</div>
            <div className="font-serif text-sm opacity-90">{p.arabic}</div>
          </button>
        ))}
      </div>

      {/* Main Interactive Counter */}
      <div className="bg-white dark:bg-zinc-800/90 rounded-3xl p-6 border border-pink-100 dark:border-zinc-700 shadow-md flex flex-col items-center justify-center relative overflow-hidden">
        <span className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-pink-400 mb-1">
          Target: {target} • Laps Completed: {lap}
        </span>
        
        {/* Arabic Display */}
        <div className="font-serif text-3xl font-bold text-zinc-800 dark:text-zinc-100 my-2">
          {phrases.find(p => p.name === selectedPhrase)?.arabic}
        </div>

        {/* Big Tap Button */}
        <button
          onClick={handleIncrement}
          className="w-44 h-44 my-4 rounded-full bg-gradient-to-tr from-rose-500 via-pink-600 to-rose-600 text-white font-extrabold text-5xl shadow-2xl shadow-rose-300 dark:shadow-rose-950/60 active:scale-95 transition-transform flex flex-col items-center justify-center border-4 border-rose-200 dark:border-rose-900"
        >
          <span>{count}</span>
          <span className="text-[10px] uppercase font-sans font-normal tracking-widest text-pink-100 mt-1">Tap to Count</span>
        </button>

        {/* Progress Bar */}
        <div className="w-full bg-rose-50 dark:bg-zinc-700 h-2 rounded-full overflow-hidden mt-2">
          <div 
            className="bg-rose-600 h-full transition-all duration-200"
            style={{ width: `${(count / target) * 100}%` }}
          ></div>
        </div>

        <button 
          onClick={handleReset}
          className="mt-4 text-xs font-semibold text-zinc-400 hover:text-rose-600 flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" /> Reset Counter
        </button>
      </div>
    </div>
  );
}

// ==================== 5. DUAS & AZKAR SCREEN ====================
function DuasScreen() {
  const [selectedCategory, setSelectedCategory] = useState('Morning');

  const categories = ['Morning', 'Evening', 'Sleeping', 'Protection', 'Forgiveness'];

  const duasList = [
    {
      id: 1,
      cat: 'Morning',
      title: 'Morning Remembrance',
      arabic: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ',
      trans: 'Asbahna wa-asbahal-mulku lillah, wal-hamdu lillah',
      meaning: 'We have entered the morning and at this very time the whole kingdom belongs to Allah.',
      repeat: 'Read 1x'
    },
    {
      id: 2,
      cat: 'Morning',
      title: 'Dua for Guidance & Provisions',
      arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلاً',
      trans: 'Allahumma inni as-aluka ilman nafi’an, wa rizqan tayyiban, wa amalan mutaqabbala',
      meaning: 'O Allah, I ask You for beneficial knowledge, good provision, and acceptable deeds.',
      repeat: 'Read 3x'
    }
  ];

  return (
    <div className="space-y-4">
      {/* Category Selector */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setSelectedCategory(c)}
            className={`px-4 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition ${
              selectedCategory === c 
                ? 'bg-rose-600 text-white shadow-md' 
                : 'bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border border-pink-100 dark:border-zinc-700'
            }`}
          >
            {c} Azkar
          </button>
        ))}
      </div>

      {/* Duas List */}
      <div className="space-y-3">
        {duasList.map((dua) => (
          <div key={dua.id} className="bg-white dark:bg-zinc-800 p-4 rounded-3xl border border-pink-100 dark:border-zinc-700 shadow-sm space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-rose-600 dark:text-pink-400">{dua.title}</span>
              <span className="text-[10px] bg-rose-50 dark:bg-rose-950/40 text-rose-600 px-2 py-0.5 rounded-full font-semibold">
                {dua.repeat}
              </span>
            </div>

            <p className="text-right font-serif text-2xl leading-loose text-zinc-800 dark:text-zinc-100 font-semibold">
              {dua.arabic}
            </p>
            <p className="text-xs italic text-zinc-500 dark:text-zinc-400">
              {dua.trans}
            </p>
            <p className="text-xs text-zinc-700 dark:text-zinc-300 font-medium">
              "{dua.meaning}"
            </p>

            <div className="flex justify-between items-center pt-2 border-t border-pink-50 dark:border-zinc-700">
              <button className="flex items-center gap-1 text-xs text-rose-600 dark:text-pink-400 font-semibold">
                <Volume2 className="w-3.5 h-3.5" /> Play Audio
              </button>
              <div className="flex gap-2">
                <button className="p-1.5 rounded-full hover:bg-rose-50 text-zinc-400"><Bookmark className="w-4 h-4" /></button>
                <button className="p-1.5 rounded-full hover:bg-rose-50 text-zinc-400"><Share2 className="w-4 h-4" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
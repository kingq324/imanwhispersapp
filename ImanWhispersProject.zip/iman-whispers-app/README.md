# Iman Whispers

A Vite + React + Tailwind starter project containing the supplied Iman Whispers app interface.

## Run locally
1. Install Node.js (18+ recommended).
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev` and open the local URL shown by Vite.

## Build for hosting
Run `npm run build`. Upload the contents of the generated `dist` folder to a static web host, or connect this repository to a host such as Vercel or Netlify.

## Install on Android
After deploying over HTTPS, open the site in Chrome on Android and use the browser menu → **Install app** or **Add to Home screen**. This creates an installable web app (PWA), not a Play Store APK/AAB.

## Important prototype notes
The supplied screen includes sample Qur'an verses, sample hadith and dua entries, and placeholder prayer times/Qibla values. These are not a complete verified religious database or live location-based calculations. Verify all religious text and sources before publishing, and connect trusted APIs/services for live prayer times, Qibla, full Qur'an data and recitation.

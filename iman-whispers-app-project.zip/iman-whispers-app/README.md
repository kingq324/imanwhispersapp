# Iman Whispers

A React + Vite + Tailwind CSS starter for the Iman Whispers Islamic app.

## Run locally

```bash
npm install
npm run dev
```

## Build for web

```bash
npm run build
npm run preview
```

## Notes

This is the initial frontend scaffold. Prayer times, Qibla direction, audio playback, notifications, and app-store packaging need real integrations and device testing before release.
